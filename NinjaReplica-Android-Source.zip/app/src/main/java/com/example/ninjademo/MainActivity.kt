package com.example.ninjademo

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 15)
    private val panel = Color.rgb(23, 23, 32)
    private val purple = Color.rgb(170, 89, 255)
    private val muted = Color.rgb(164, 164, 180)
    private lateinit var content: LinearLayout
    private var autoPlay = false
    private var autoQueue = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun shape(color: Int, radius: Float = 18f, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = radius
            if (stroke != 0) setStroke(1, stroke)
        }

    private fun text(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun button(label: String, onClick: () -> Unit): TextView =
        text(label, 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(16, 15, 16, 15)
            background = shape(purple, 16f)
            setOnClickListener { onClick() }
        }

    private fun base(title: String, subtitle: String) {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 26)
            setBackgroundColor(bg)
        }
        scroll.addView(content)
        setContentView(scroll)
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = ImageView(this)
        try { logo.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(assets.open("main_logo.png"), null)) } catch (_: Exception) {}
        brand.addView(logo, LinearLayout.LayoutParams(62, 62))
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14,0,0,0) }
        labels.addView(text(title, 24f, Color.WHITE, true))
        labels.addView(text(subtitle, 12f, muted))
        brand.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(brand)
        val line = View(this).apply { setBackgroundColor(Color.rgb(48, 43, 58)) }
        content.addView(line, LinearLayout.LayoutParams(-1, 1).apply { topMargin = 18; bottomMargin = 18 })
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 16, 16, 16)
        background = shape(panel, 18f, Color.rgb(53, 45, 68))
    }

    private fun showHome() {
        base("NINJA ENGINE", "SANSXD • UI DEMO")
        val note = card()
        note.addView(text("Welcome back, Ninja", 19f, Color.WHITE, true))
        note.addView(text("Demo interface inspired by the supplied app assets.", 13f, muted).apply { setPadding(0,7,0,0) })
        content.addView(note, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 16 })

        val section = text("FEATURE CONTROL", 12f, purple, true)
        content.addView(section, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        content.addView(featureRow("AutoPlay", "Tap to switch demo state", autoPlay, "autoplay_on.png", "autoplay_off.png") {
            autoPlay = !autoPlay; showHome()
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        content.addView(featureRow("AutoQueue", "Tap to switch demo state", autoQueue, "autoqueue_on.png", "autoqueue_off.png") {
            autoQueue = !autoQueue; showHome()
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 16 })

        val launch = button("LAUNCH DEMO") {
            AlertDialog.Builder(this)
                .setTitle("Demo mode")
                .setMessage("This is a visual demo only. It does not connect to or automate 8 Ball Pool or other third-party apps.")
                .setPositiveButton("OK", null).show()
        }
        content.addView(launch, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        val login = text("ACCESS SETTINGS  ›", 14f, muted, true).apply {
            gravity = Gravity.CENTER; setPadding(12, 18, 12, 18)
            setOnClickListener { showAccess() }
        }
        content.addView(login, LinearLayout.LayoutParams(-1, -2))
        content.addView(text("SAFE PREVIEW • NO GAME MODIFICATION", 10f, muted).apply {
            gravity = Gravity.CENTER; setPadding(0, 22, 0, 0)
        })
    }

    private fun featureRow(name: String, desc: String, enabled: Boolean, onAsset: String, offAsset: String, toggle: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 12, 12, 12)
            background = shape(panel, 18f, Color.rgb(53, 45, 68))
        }
        val icon = ImageView(this)
        try {
            val f = if (enabled) onAsset else offAsset
            icon.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(assets.open(f), null))
        } catch (_: Exception) {}
        row.addView(icon, LinearLayout.LayoutParams(58, 58))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,0,4,0) }
        texts.addView(text(name, 16f, Color.WHITE, true))
        texts.addView(text(if (enabled) "Enabled (demo)" else desc, 12f, muted).apply { setPadding(0,4,0,0) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val switch = Switch(this).apply { isChecked = enabled; buttonTintList = android.content.res.ColorStateList.valueOf(purple); setOnClickListener { toggle() } }
        row.addView(switch)
        row.setOnClickListener { toggle() }
        return row
    }

    private fun showAccess() {
        base("ACCESS SETTINGS", "Local demo only")
        val c = card()
        c.addView(text("Demo access", 19f, Color.WHITE, true))
        c.addView(text("This screen does not validate VIP keys or collect credentials.", 13f, muted).apply { setPadding(0,8,0,14) })
        val key = EditText(this).apply {
            hint = "Optional display name"; setHintTextColor(muted); setTextColor(Color.WHITE)
            background = shape(Color.rgb(35,35,47), 12f); setPadding(14,12,14,12)
        }
        c.addView(key, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 })
        c.addView(button("SAVE DISPLAY NAME") {
            val name = key.text.toString().trim().ifEmpty { "Ninja" }
            Toast.makeText(this, "Demo name: $name", Toast.LENGTH_SHORT).show()
            showHome()
        })
        content.addView(c)
        content.addView(text("No Facebook/Google login, VIP key system, or game launch integration is included.", 12f, muted).apply { setPadding(0,16,0,0) })
        content.addView(button("BACK TO HOME") { showHome() }, LinearLayout.LayoutParams(-1,-2).apply { topMargin = 18 })
    }
}