# Ninja UI Demo (Android Studio)

This is an original demo implementation inspired by the visual assets in the user-provided ZIP. It is not the original Ninja Engine.

## Included
- Dark purple/black UI inspired by the supplied logo/icons
- AutoPlay and AutoQueue visual toggles (demo state only)
- Access settings screen with local display-name field
- Launch Demo informational dialog

## Safety and limitations
- Does not interact with, automate, modify, or inject into 8 Ball Pool or any third-party app.
- Does not collect passwords, VIP keys, or third-party login credentials.
- The original APK's backend and internal logic have not been reproduced.
- An Android SDK/Gradle installation is required to build an APK.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build APK(s)**.
The generated APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
