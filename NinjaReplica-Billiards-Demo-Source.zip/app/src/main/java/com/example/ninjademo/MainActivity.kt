package com.example.ninjademo

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 12, 17)
    private val panel = Color.rgb(24, 27, 36)
    private val gold = Color.rgb(244, 190, 77)
    private val muted = Color.rgb(190, 195, 205)
    private var angle = 25
    private var power = 65
    private lateinit var table: BilliardsView
    private lateinit var angleLabel: TextView
    private lateinit var powerLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun shape(color: Int, radius: Float = 18f, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = radius
            if (stroke != 0) setStroke(1, stroke)
        }

    private fun label(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun button(value: String, action: () -> Unit): TextView = label(value, 14f, Color.BLACK, true).apply {
        gravity = Gravity.CENTER
        setPadding(14, 12, 14, 12)
        background = shape(gold, 14f)
        setOnClickListener { action() }
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(24, 28, 24, 28); setBackgroundColor(bg)
        }
        root.addView(label("NINJAREPLICA", 27f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        root.addView(label("BILLIARDS AIM • STANDALONE DEMO", 12f, muted).apply {
            gravity = Gravity.CENTER; setPadding(0, 8, 0, 26)
        })
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18)
            background = shape(panel, 20f, Color.rgb(65, 65, 76))
        }
        card.addView(label("Demo meja biliar", 20f, Color.WHITE, true))
        card.addView(label("Latih sudut bidik, kekuatan pukulan, dan pantulan bola pada simulasi mandiri. Tidak terhubung ke 8 Ball Pool.", 14f, muted).apply {
            setPadding(0, 10, 0, 18)
        })
        card.addView(button("BUKA SIMULASI") { showBilliardsDemo() })
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        root.addView(label("SIMULASI LOKAL • TANPA MODIFIKASI GAME", 10f, muted).apply {
            gravity = Gravity.CENTER; setPadding(0, 22, 0, 0)
        })
        setContentView(root)
    }

    private fun showBilliardsDemo() {
        val root = FrameLayout(this).apply { setBackgroundColor(bg) }
        table = BilliardsView(this)
        root.addView(table, FrameLayout.LayoutParams(-1, -1))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            background = shape(Color.argb(238, 24, 27, 36), 20f, Color.rgb(100, 94, 78))
            elevation = 12f
        }
        controls.addView(label("AIM CONTROL  •  DEMO", 14f, gold, true))
        angleLabel = label("Sudut bidik: $angle°", 13f, Color.WHITE, true)
        controls.addView(angleLabel)
        val angleBar = SeekBar(this).apply {
            max = 359; progress = angle
            progressTintList = android.content.res.ColorStateList.valueOf(gold)
            thumbTintList = android.content.res.ColorStateList.valueOf(gold)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    angle = value; angleLabel.text = "Sudut bidik: $angle°"; table.invalidate()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        controls.addView(angleBar)
        powerLabel = label("Kekuatan pukulan: $power%", 13f, Color.WHITE, true)
        controls.addView(powerLabel)
        val powerBar = SeekBar(this).apply {
            max = 100; progress = power
            progressTintList = android.content.res.ColorStateList.valueOf(gold)
            thumbTintList = android.content.res.ColorStateList.valueOf(gold)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    power = value; powerLabel.text = "Kekuatan pukulan: $power%"; table.invalidate()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        controls.addView(powerBar)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        buttons.addView(button("ATUR ULANG") { angle = 25; power = 65; showBilliardsDemo() }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(button("KEMBALI") { showHome() }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 10 })
        controls.addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        controls.addView(label("Garis putus-putus = perkiraan jalur dan pantulan. Simulasi visual saja.", 10f, muted).apply {
            setPadding(0, 8, 0, 0)
        })
        val lp = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            setMargins(14, 14, 14, 18)
        }
        root.addView(controls, lp)

        // Allow the floating control panel to be dragged vertically within the screen.
        controls.setOnTouchListener(object : View.OnTouchListener {
            private var startY = 0f
            private var startTop = 0
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { startY = event.rawY; startTop = (v.layoutParams as FrameLayout.LayoutParams).bottomMargin; return false }
                    MotionEvent.ACTION_MOVE -> {
                        val p = v.layoutParams as FrameLayout.LayoutParams
                        p.bottomMargin = (startTop + (startY - event.rawY).toInt()).coerceIn(0, root.height.coerceAtLeast(1) - v.height)
                        p.gravity = Gravity.BOTTOM
                        v.layoutParams = p
                    }
                }
                return false
            }
        })
        setContentView(root)
    }

    private inner class BilliardsView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val felt = Color.rgb(20, 112, 75)
        private val rail = Color.rgb(104, 62, 34)
        private val ballWhite = Color.rgb(248, 247, 232)
        private val ballRed = Color.rgb(218, 63, 60)
        private val lineGold = Color.rgb(255, 220, 104)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (w < 10 || h < 10) return
            canvas.drawColor(Color.rgb(11, 15, 19))
            val left = w * .055f; val top = h * .10f; val right = w * .945f; val bottom = h * .72f
            paint.color = rail; paint.style = Paint.Style.FILL
            canvas.drawRoundRect(left, top, right, bottom, 24f, 24f, paint)
            val inset = w * .035f
            paint.color = felt
            canvas.drawRoundRect(left + inset, top + inset, right - inset, bottom - inset, 12f, 12f, paint)
            val l = left + inset + 8f; val t = top + inset + 8f; val r = right - inset - 8f; val b = bottom - inset - 8f
            val hole = w * .025f
            paint.color = Color.rgb(5, 7, 8)
            for (x in floatArrayOf(l, (l + r) / 2f, r)) {
                canvas.drawCircle(x, t, hole, paint); canvas.drawCircle(x, b, hole, paint)
            }
            paint.style = Paint.Style.FILL
            val cueX = l + (r-l)*.23f; val cueY = t + (b-t)*.55f
            val targetX = l + (r-l)*.68f; val targetY = t + (b-t)*.43f
            val radius = w * .025f
            drawBall(canvas, cueX, cueY, radius, ballWhite, "")
            drawBall(canvas, targetX, targetY, radius, ballRed, "8")

            // A dashed trajectory ray with up to two cushion reflections, entirely inside this canvas.
            val radians = Math.toRadians(angle.toDouble())
            var x = cueX; var y = cueY
            var dx = kotlin.math.cos(radians).toFloat(); var dy = -kotlin.math.sin(radians).toFloat()
            val path = Path().apply { moveTo(x, y) }
            val maxDistance = (r-l) * (0.25f + power / 100f * 1.8f)
            var remaining = maxDistance
            repeat(3) {
                if (remaining <= 0f) return@repeat
                var tx = Float.POSITIVE_INFINITY; var ty = Float.POSITIVE_INFINITY
                if (dx > 0f) tx = (r - x) / dx else if (dx < 0f) tx = (l - x) / dx
                if (dy > 0f) ty = (b - y) / dy else if (dy < 0f) ty = (t - y) / dy
                val step = minOf(tx, ty, remaining).coerceAtLeast(0f)
                x += dx * step; y += dy * step; path.lineTo(x, y); remaining -= step
                if (step >= tx && tx <= ty) dx = -dx else if (step >= ty) dy = -dy else remaining = 0f
            }
            paint.color = lineGold; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
            paint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(12f, 8f), 0f)
            canvas.drawPath(path, paint); paint.pathEffect = null; paint.style = Paint.Style.FILL
            paint.color = Color.WHITE; paint.textSize = 13f
            canvas.drawText("SIMULASI JALUR BIDIK", left, bottom + 24f, paint)
            paint.color = muted; paint.textSize = 11f
            canvas.drawText("Sudut $angle°  •  Kekuatan $power%", left, bottom + 44f, paint)
        }

        private fun drawBall(canvas: Canvas, x: Float, y: Float, radius: Float, color: Int, number: String) {
            paint.style = Paint.Style.FILL; paint.color = Color.argb(70, 0, 0, 0)
            canvas.drawCircle(x + 2f, y + 3f, radius, paint)
            paint.color = color; canvas.drawCircle(x, y, radius, paint)
            paint.color = Color.argb(90, 255, 255, 255)
            canvas.drawCircle(x - radius * .28f, y - radius * .30f, radius * .27f, paint)
            if (number.isNotEmpty()) {
                paint.color = Color.WHITE; canvas.drawCircle(x, y, radius * .48f, paint)
                paint.color = Color.BLACK; paint.textSize = radius * .85f; paint.textAlign = Paint.Align.CENTER
                canvas.drawText(number, x, y + radius * .3f, paint); paint.textAlign = Paint.Align.LEFT
            }
        }
    }
}
